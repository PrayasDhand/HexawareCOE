export class Book {
    _id!:number;
    bookName!:String;
    authorName!:String;
    price!:String;
    path!: String;


}
